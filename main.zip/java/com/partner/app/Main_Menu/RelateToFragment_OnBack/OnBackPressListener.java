package com.partner.app.Main_Menu.RelateToFragment_OnBack;

/**
 * Created by AQEEL on 3/30/2018.
 */

public interface OnBackPressListener {
    public boolean onBackPressed();
}
