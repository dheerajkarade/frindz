package com.partner.app.GoogleMap;

/**
 * Created by Nabeel on 3/13/2018.
 */

public class SavedAddress {
    String Latitude, Longitude;
        public String getLatitude()
    { return Latitude; }
        public void setLatitude(String latitude) {
        Latitude = latitude; }
        public String getLongitude() {
        return Longitude; }
        public void setLongitude(String longitude) {
        Longitude = longitude; }
}
